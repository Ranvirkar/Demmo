package com.app.service;

import java.util.List;

import com.app.Entity.Car;
import com.app.Entity.CarType;

public interface CarService {

	public Car addNewCar(Car c);
	public Car updateCar(Long car_no,Car c);
	public void DeleteCarByName(String car_name);
	public List<Car> getCarByType(CarType type);
}
