package com.app.exception;

public class RailwayException extends RuntimeException {
	
public RailwayException(String s)
{
	super(s);
}
}
