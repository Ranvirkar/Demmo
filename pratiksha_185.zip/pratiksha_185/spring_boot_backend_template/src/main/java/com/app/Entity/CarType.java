package com.app.Entity;

public enum CarType {
   SEDAN,SUV,HATCHBACK,SPORTS
}
