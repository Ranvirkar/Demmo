package com.app.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.Entity.Car;
import com.app.Entity.CarType;

public interface CarRepository extends JpaRepository<Car,Long> {

	Car findByCname(String car_name);

	List<Car> findByCartype(CarType type);

}
