package com.app.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
public class Car {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long car_no;
	@NotBlank
	private String cname;
	@NotBlank
	private String car_color;
	@NotBlank
	private String fueltype;
	@NotNull
	private CarType cartype;
	@NotNull
	private Long car_price;
	@NotBlank
	private String transmission;
	public Long getCar_no() {
		return car_no;
	}
	public void setCar_no(Long car_no) {
		this.car_no = car_no;
	}
	public String getcname() {
		return cname;
	}
	public void setcname(String cname) {
		this.cname = cname;
	}
	public String getCar_color() {
		return car_color;
	}
	public void setCar_color(String car_color) {
		this.car_color = car_color;
	}
	public String getFueltype() {
		return fueltype;
	}
	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}
	public CarType getCartype() {
		return cartype;
	}
	public void setCartype(CarType cartype) {
		this.cartype = cartype;
	}
	public Long getCar_price() {
		return car_price;
	}
	public void setCar_price(Long car_price) {
		this.car_price = car_price;
	}
	public String getTransmission() {
		return transmission;
	}
	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	public Car(Long car_no, @NotBlank String cname, @NotBlank String car_color, @NotBlank String fueltype,
			@NotNull CarType cartype, @NotNull Long car_price, @NotBlank String transmission) {
		super();
		this.car_no = car_no;
		this.cname = cname;
		this.car_color = car_color;
		this.fueltype = fueltype;
		this.cartype = cartype;
		this.car_price = car_price;
		this.transmission = transmission;
	}
	@Override
	public String toString() {
		return "Car [car_no=" + car_no + ", cname=" + cname + ", car_color=" + car_color + ", fueltype="
				+ fueltype + ", cartype=" + cartype + ", car_price=" + car_price + ", transmission=" + transmission
				+ "]";
	}
	
	public Car() {
		super();
	}
	
	
	
	
	

}
