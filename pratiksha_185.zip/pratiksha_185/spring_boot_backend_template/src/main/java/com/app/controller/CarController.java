package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Entity.Car;
import com.app.Entity.CarType;
import com.app.service.CarService;


@RestController
@RequestMapping("/car")
public class CarController {

	@Autowired
	private CarService carservice;
	
	@PostMapping
	public ResponseEntity<Car> addNewCar(@RequestBody Car c)
	{
		return new ResponseEntity<Car>(carservice.addNewCar(c),HttpStatus.OK);
	}
	
	@GetMapping("/cartype/{type}")
	public ResponseEntity<List<Car>> getByName(@PathVariable CarType type)
	{
		return new ResponseEntity<>(carservice.getCarByType(type),HttpStatus.OK);
	}
	
    @PutMapping("/car_no/{no}")
    public ResponseEntity<Car> updateNewCar(@PathVariable Long no, @RequestBody Car c)
	{
		return new ResponseEntity<Car>(carservice.updateCar(no,c),HttpStatus.OK);
	}
    
    
    
    @DeleteMapping("/cname/{name}")
    public ResponseEntity<String> deleteByName(@PathVariable String name)
    {
    	carservice.DeleteCarByName(name);
    	return new ResponseEntity<>("Deleted Car Data",HttpStatus.OK);
    }
	

	
	
}
