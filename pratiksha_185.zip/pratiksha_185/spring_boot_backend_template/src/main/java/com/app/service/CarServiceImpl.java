package com.app.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Entity.Car;
import com.app.Entity.CarType;
import com.app.exception.RailwayException;
import com.app.repository.CarRepository;

@Service
@Transactional
public class CarServiceImpl implements CarService {

	@Autowired
	private CarRepository carrepo;
	
	@Override
	public Car addNewCar(Car c) {
		if(c==null)
		{
			throw new RailwayException("You are Giving Null Value");
		}
		else
		{
		return carrepo.save(c);
		}
	}

	@Override
	public Car updateCar(Long car_no, Car c) {
		Optional<Car> c1=carrepo.findById(car_no);
		if(c1.isPresent())
		{
			Car upcar=c1.get();
			upcar.setcname(c.getcname());
			upcar.setCar_color(c.getCar_color());
			upcar.setCar_price(c.getCar_price());
			upcar.setCartype(c.getCartype());
			upcar.setFueltype(c.getFueltype());
			upcar.setTransmission(c.getTransmission());
			return carrepo.save(upcar);
		}
		else
		{
			throw new RailwayException("You are Giving Wrong Id");
		}
		
	}

	@Override
	public void DeleteCarByName(String car_name) {
		Car c1=carrepo.findByCname(car_name);
		if(c1==null)
		{
			throw new RailwayException("You are Giving Wrong Car Name");
		}
		else
		{
		carrepo.deleteById(c1.getCar_no());
		}
	}

	@Override
	public List<Car> getCarByType(CarType type) {
		return carrepo.findByCartype(type);
	}

}
